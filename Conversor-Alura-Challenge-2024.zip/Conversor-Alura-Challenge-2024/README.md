# Conversor de unidades\!

### Información de la materia
  * **Asignatura:** Trabajo de Capacitación Profesional (1110)
  * **Docentes**: [Pan Néstor Ariel](https://ingenieria.unlam.edu.ar/descargas/48_2011CVPanNstorAriel.pdf) y 
Guzman Gabriel Eduardo
  * **Fecha de entrega:** 12 de mayo del 2019
  * **Nota:**

### Miembros de grupo
  * [Ruiz Carletti Emiliano](https://github.com/ArtificialNerd)
  * [Strficek Matías](https://github.com/matiasstr)
