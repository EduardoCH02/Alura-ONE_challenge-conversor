/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversores;

/**
 *
 * @author Edaurdo
 */
 
public class Divisas {
    
  public double valor; // En pesos mexicanos (MXN)
    
    // Tasas de cambio estimadas
    private static final double USD_TO_MXN = 18.0; // 1 USD = 18 MXN
    private static final double EUR_TO_MXN = 19.5; // 1 EUR = 19.5 MXN
    private static final double GBP_TO_MXN = 22.0; // 1 GBP = 22 MXN
    
    public Divisas(double cantidad, String unidad) {
        switch(unidad) {
            case "MXN":
                this.valor = cantidad; // En pesos
                break;
            case "USD":
                this.valor = cantidad * USD_TO_MXN; // Convertir USD a MXN
                break;
            case "EUR":
                this.valor = cantidad * EUR_TO_MXN; // Convertir EUR a MXN
                break;
            case "GBP":
                this.valor = cantidad * GBP_TO_MXN; // Convertir GBP a MXN
                break;
            default:
                System.out.printf("Unidad de moneda %s desconocida\n", unidad);
                this.valor = 0;
                break;
        }
    }
    
    public double Cambiar(String unidad) {
        switch(unidad) {
            case "MXN":
                return this.valor; // En pesos
            case "USD":
                return this.valor / USD_TO_MXN; // Convertir MXN a USD
            case "EUR":
                return this.valor / EUR_TO_MXN; // Convertir MXN a EUR
            case "GBP":
                return this.valor / GBP_TO_MXN; // Convertir MXN a GBP
            default:
                System.out.printf("Unidad de moneda %s desconocida\n", unidad);
                return 0;
        }
    }
}